package com.example.sjview;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class SubjectArray  {

    private Subject[] subjects;
    private int Subjectcount;
    ArrayList<Subject> arrayl = new ArrayList<Subject>();


    public SubjectArray() {

        subjects = new Subject[100];
        Subjectcount = 0;
    }
    public Subject searchByCode(String code) {

        for (int i = 0; i < Subjectcount; ++i) {

            if (subjects[i].getCode().equalsIgnoreCase(code)) {
                return subjects[i];

            }
        }
        return null;
    }

    public void addSubject()
    {
             ArrayList<Subject> arrayl = new ArrayList<Subject>();
           arrayl.add(new Subject("MAD","AAA",1,2,2020));
        arrayl.add(new Subject("M2D","AAB",1,2,2020));
        arrayl.add(new Subject("M3D","AAC",1,2,2020));
        arrayl.add(new Subject("M4D","AAD",1,2,2020));

    }


    public String toString()
    {
        String SubjectsToString = "";
        for(int i = 0; i < Subjectcount; i++)
        {
            SubjectsToString = SubjectsToString +  subjects[i].toString() + "\n";
        }
        return SubjectsToString;
    }

    public int getCount() {
        int count = 0;
        for(int i = 0; i < Subjectcount; i++)
        {
            count = i;
        }

        return count;
    }




}
