package com.example.sjview;

import androidx.appcompat.app.AppCompatActivity;

public class Subject  {

    String _code;
    String _name;
    String _date;
    int day;
    int mon;
    int year;

    public Subject(String code, String name, int day, int mon, int year) {
        this._code = code;
        this._name = name;
        this.day = day;
        this.mon = mon;
        this.year = year;
    }

    public String getCode() {
        return this._code;
    }
    public void setCode(String Code) {
        this._code = Code;
    }
    public String getName() {
        return this._name;
    }
    public void setName(String name) {
        this._name = name;
    }
    public String getDate() {
        return this._date;
    }
    public void setDate(String date) {
        this._date = date;
    }
    public int getday() {
        return this.day;
    }
    public void setDay(int day) {
        this.day = day;
    }
    public int getmon() {
        return this.mon;
    }
    public void setMon(int mon) {
        this.mon = mon;
    }
    public int getYear() {
        return this.mon;
    }
    public void setYear(int year) {
        this.mon = year;
    }

    public String toString() {
        String s = " ";
        String body = _code + s +_name + s + day + s + mon + s +year ;
        return body;
    }


}
