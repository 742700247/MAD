package com.example.sjview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    Button mSubject;
    TextView mSubSelected;


    String[] listSubject;
    boolean[] checkedItems;
    ArrayList<Integer> mUserItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mSubject = (Button) findViewById(R.id.button);
        mSubSelected = (TextView) findViewById(R.id.textView);

        listSubject = getResources().getStringArray(R.array.subject_name);
        checkedItems = new boolean[listSubject.length];

        ArrayList<Subject> arrayl = new ArrayList<Subject>();





        mSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                mBuilder.setTitle(R.string.dialog_title);
                mBuilder.setMultiChoiceItems(listSubject, checkedItems, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int position, boolean isChecked) {

                        if(isChecked){
                            mUserItems.add(position);
                        }else{
                            mUserItems.remove((Integer.valueOf(position)));
                        }
                    }
                });

                mBuilder.setCancelable(false);
                mBuilder.setPositiveButton(R.string.ok_label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        String item = "";
                        for (int i = 0; i < mUserItems.size(); i++) {
                            item = item + listSubject[mUserItems.get(i)];
                            if (i != mUserItems.size() - 1) {
                                item = item + ", ";
                            }
                        }

                        SpannableString ss = new SpannableString(item);


                        ClickableSpan clickableSpan1 = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View widget) {
                                Toast.makeText(MainActivity.this,"one",Toast.LENGTH_SHORT);
                            }

                        };
                        ClickableSpan clickableSpan2 = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View widget) {
                                Toast.makeText(MainActivity.this,"two",Toast.LENGTH_SHORT);
                            }
                        };
                        ClickableSpan clickableSpan3 = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View widget) {
                                Toast.makeText(MainActivity.this,"three",Toast.LENGTH_SHORT);
                            }
                        };
                        ClickableSpan clickableSpan4 = new ClickableSpan() {
                            @Override
                            public void onClick(@NonNull View widget) {
                                Toast.makeText(MainActivity.this,"four",Toast.LENGTH_SHORT);
                            }
                        };
                        ss.setSpan(clickableSpan1,0,8, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        ss.setSpan(clickableSpan2,9,16, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        ss.setSpan(clickableSpan3,17,25, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        ss.setSpan(clickableSpan4,25,34, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

                        mSubSelected.setText(ss);

                        mSubSelected.setMovementMethod(LinkMovementMethod.getInstance());
                        mSubSelected.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                startActivity(new Intent(MainActivity.this, SecondActivity.class));
                            }
                        });

                    }
                });


                mBuilder.setNegativeButton(R.string.dismiss_label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });

                mBuilder.setNeutralButton(R.string.clear_all_label, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        for (int i = 0; i < checkedItems.length; i++) {
                            checkedItems[i] = false;
                            mUserItems.clear();
                            mSubSelected.setText("");
                        }
                    }
                });


                AlertDialog mDialog = mBuilder.create();
                mDialog.show();
            }
        });


    }
}